var trex,trexImage
var ground,groundImage
var invisableGround
var cloud,cloudImage
var obstacle,obstacleImage1,obstacleImage2,obstacleImage3,obstacleImage4,obstacleImage5,obstacleImage6
var restart,restartImage
var gameover,gameoverImage
var dead_trex
var PLAY=1
var END=0
var gamestate=PLAY
var score=0
var cactusGroup,cloudGroup
function preload(){
  trexImage=loadAnimation("trex1.png","trex3.png","trex4.png")
  groundImage=loadImage("ground2.png")
  cloudImage=loadImage("cloud.png")
  obstacleImage1=loadImage("obstacle1.png")
   obstacleImage2=loadImage("obstacle2.png")
   obstacleImage3=loadImage("obstacle3.png")
   obstacleImage4=loadImage("obstacle4.png")
   obstacleImage5=loadImage("obstacle5.png")
   obstacleImage6=loadImage("obstacle6.png")
  gameoverImage=loadImage("gameOver.png")
  restartImage=loadImage("restart.png")
  dead_trex=loadImage("dead_trex.png")
}
function setup(){
  createCanvas(600,200)
  trex=createSprite(50,150,20,20)
  trex.addAnimation("trexImage",trexImage)
  trex.addAnimation("dead_trex",dead_trex)
  ground=createSprite(300,180,600,20)
  ground.addImage("groundImage",groundImage)
  invisableGround=createSprite(300,190,600,10)
  invisableGround.visible=false
  cactusGroup=new Group()
  cloudGroup=new Group()
  gameover=createSprite(300,100,20,20)
  gameover.addImage("gameoverImage",gameoverImage )
  restart=createSprite(300,150,20,20)
  restart.addImage("restartImage",restartImage)
}
function draw(){
  background("black")
  drawSprites()
  if (gamestate===PLAY){
     gameover.visible=false
    restart.visible=false
    if(ground.x <0){
    ground.x=ground.width/2
  }
  ground.velocityX=-4
  if (keyDown("space")&&trex.y>=138){
    trex.velocityY=-10
    
  }
    trex.velocityY=trex.velocityY+0.8
  console.log(trex.y)
CLOUD();
CACTUS();
    if (cactusGroup.isTouching(trex)){
      gamestate=END
    }
  }
  else if (gamestate===END){
    ground.velocityX = 0
    cloudGroup.setVelocityXEach(0)
    cactusGroup.setVelocityXEach(0)
    trex.velocityY = 0
    cloudGroup.setLifetimeEach(-1)
    cactusGroup.setLifetimeEach(-1)
    gameover.visible=true
    restart.visible=true
    restart.depth=obstacle.depth
    restart.depth=restart.depth+1
    trex.changeAnimation("dead_trex",dead_trex)
  }
  if (mousePressedOver(restart)){
    Restart();
  }
  trex.collide(invisableGround)

}
function CLOUD(){
  if (frameCount%60===0){
    cloud=createSprite(600,100,0.5,0.5)
    cloud.addImage("cloudImage",cloudImage)
    cloud.velocityX=-4
    cloud.depth=trex.depth
    trex.depth=trex.depth+1
    cloud.y=Math.round(random(1,100))
    cloud.lifetime=600/4
    cloudGroup.add(cloud)
  }
}
function CACTUS(){
  if (frameCount%60===0){
    obstacle=createSprite(600,170,10,10)
    var rand=Math.round(random(1,6))
    switch(rand){
      case 1:obstacle.addImage("obstacleImage1",obstacleImage1);
        break;
        case 2:obstacle.addImage("obstacleImage2",obstacleImage2);
        break;
        case 3:obstacle.addImage("obstacleImage3",obstacleImage3);
        break;
        case 4:obstacle.addImage("obstacleImage4",obstacleImage4);
        break;
        case 5:obstacle.addImage("obstacleImage5",obstacleImage5);
        break;
        case 6:obstacle.addImage("obstacleImage6",obstacleImage6);
        break;
        default:break;
    }
    obstacle.lifetime=600/4
    obstacle.scale=0.5
    obstacle.velocityX=-4
    cactusGroup.add(obstacle)
  }
}
function Restart(){
  gamestate = PLAY
  gameover.visible=false
    restart.visible=false
  cloudGroup.destroyEach()
  cactusGroup.destroyEach()
  trex.changeAnimation("trexImage",trexImage)
}